Lab 5 - Static Code Analysis (PES1UG24AM446)
Drop the whole Lab5 folder into PES1UG24AM446_SELAB, then:
  git add Lab5 && git commit -m "Add Lab 5 deliverables" && git push origin main

patches/ = the 3 per-tool commits (Bandit, Flake8, Pylint). To recreate them in the
assigned repo SETAPESU26/L5_27_address_book (against the original address_book.py):
  git am Lab5/patches/*.patch
